#include "header.h"

/*
 * Function : iskeyword()
 * Purpose  : Checks whether the given word is a data type keyword
 * Return   : 1 if keyword found, 0 otherwise
 */

int iskeyword(const char *word)
{
    int size = sizeof(keywords_data) / sizeof(keywords_data[0]);

    for(int i = 0; i < size; i++)
    {
        if(strcmp(word, keywords_data[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}


/*
 * Function : is_nondatakeyword()
 * Purpose  : Checks whether the given word is a non-data keyword
 * Return   : 1 if keyword found, 0 otherwise
 */

int is_nondatakeyword(const char *word)
{
    int size = sizeof(keywords_non_data) / sizeof(keywords_non_data[0]);

    for(int i = 0; i < size; i++)
    {
        if(strcmp(word, keywords_non_data[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}


/*
 * Function : isoperator()
 * Purpose  : Checks whether the given character is an operator
 * Return   : 1 if operator found, 0 otherwise
 */

int isoperator(char ch)
{
    int size = sizeof(operators) / sizeof(operators[0]);

    for(int i = 0; i < size; i++)
    {
        if(operators[i] == ch)
        {
            return 1;
        }
    }

    return 0;
}


/*
 * Function : issymbol()
 * Purpose  : Checks whether the given character is a symbol
 * Return   : 1 if symbol found, 0 otherwise
 */

int issymbol(char ch)
{
    int size = sizeof(symbols) / sizeof(symbols[0]);

    for(int i = 0; i < size; i++)
    {
        if(symbols[i] == ch)
        {
            return 1;
        }
    }

    return 0;
}