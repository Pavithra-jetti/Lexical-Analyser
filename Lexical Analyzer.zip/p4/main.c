#include "header.h"

int main(int argc, char *argv[])
{
    if(argc < 2)
    {
        printf(RED "Error: Please provide a C source file\n" RESET);
        return 0;
    }

    FILE *fin = fopen(argv[1], "r");

    if(fin == NULL)
    {
        printf(RED "Error: Unable to open file\n" RESET);
        return 0;
    }

    char ch;
    char next;
    char word[100];
    int i = 0;
    int line = 1;

    int curly_count = 0;
    int round_count = 0;


    while((ch = fgetc(fin)) != EOF)
    {

        /* Count line number */
        if(ch == '\n')
        {
            line++;
        }


        /* Preprocessor Directive */
        if(ch == '#')
        {
            i = 0;
            word[i++] = ch;

            while((ch = fgetc(fin)) != '\n' && ch != EOF)
            {
                word[i++] = ch;
            }

            word[i] = '\0';

            printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                    line,
                    "Preprocessor directive",
                    word);

            continue;
        }


        /* Comments and Division operator */
        else if(ch == '/')
        {
            next = fgetc(fin);


            /* Single line comment */
            if(next == '/')
            {
                while((ch = fgetc(fin)) != '\n' && ch != EOF);

                line++;
                continue;
            }


            /* Multi line comment */
            else if(next == '*')
            {
                while(1)
                {
                    ch = fgetc(fin);

                    if(ch == EOF)
                        break;

                    if(ch == '\n')
                        line++;

                    if(ch == '*')
                    {
                        next = fgetc(fin);

                        if(next == '/')
                            break;

                        ungetc(next, fin);
                    }
                }

                continue;
            }


            /* Division operator */
            else
            {
                ungetc(next, fin);

                printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                       line,
                       "Operator",
                       ch);

                continue;
            }
        }


        /* Character Literal */
        else if(ch == '\'')
        {
            i = 0;
            word[i++] = ch;

            while((ch = fgetc(fin)) != EOF)
            {
                word[i++] = ch;

                if(ch == '\'')
                {
                    break;
                }

                if(ch == '\n')
                {
                    printf(RED "Error: Character literal not closed\n" RESET);
                    return 0;
                }
            }

            word[i] = '\0';

            printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                   line,
                   "Character literal",
                   word);

            continue;
        }


        /* String Literal */
        else if(ch == '"')
        {
            i = 0;
            word[i++] = ch;


            while((ch = fgetc(fin)) != EOF)
            {
                word[i++] = ch;

                if(ch == '"')
                {
                    break;
                }

                if(ch == '\n')
                {
                    line++;
                }
            }


            if(ch != '"')
            {
                printf(RED "Error: String literal not closed\n" RESET);
                return 0;
            }


            word[i] = '\0';


            printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                   line,
                   "String literal",
                   word);

            continue;
        }



        /* Numeric Constant */
        else if(isdigit(ch))
        {
            i = 0;
            word[i++] = ch;


            while(isdigit(ch = fgetc(fin)))
            {
                word[i++] = ch;
            }

            word[i] = '\0';


            printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                   line,
                   "Numeric constant",
                   word);


            ungetc(ch, fin);

            continue;
        }



        /* Identifier and Keywords */
        else if(isalpha(ch) || ch == '_')
        {
            i = 0;
            word[i++] = ch;


            while(isalnum(ch = fgetc(fin)) || ch == '_')
            {
                word[i++] = ch;
            }


            word[i] = '\0';


            if(iskeyword(word))
            {
                printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                       line,
                       "Keyword",
                       word);
            }

            else if(is_nondatakeyword(word))
            {
                printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                       line,
                       "Non-data keyword",
                       word);
            }

            else
            {
                printf(BLUE "Line %2d : %-25s : %s\n" RESET,
                       line,
                       "Identifier",
                       word);
            }


            ungetc(ch, fin);

            continue;
        }



        /* Operators */
        else if(isoperator(ch))
        {
            printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                   line,
                   "Operator",
                   ch);

            continue;
        }



        /* Round Braces */
        else if(ch == '(')
        {
            round_count++;

            printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                   line,
                   "Round brace opening",
                   ch);
        }


        else if(ch == ')')
        {
            round_count--;

            if(round_count < 0)
            {
                printf(RED "Error: Round braces not balanced\n" RESET);
                return 0;
            }


            printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                   line,
                   "Round brace closing",
                   ch);
        }



        /* Curly Braces */
        else if(ch == '{')
        {
            curly_count++;

            printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                   line,
                   "Curly brace opening",
                   ch);
        }


        else if(ch == '}')
        {
            curly_count--;


            if(curly_count < 0)
            {
                printf(RED "Error: Curly braces not balanced\n" RESET);
                return 0;
            }


            printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                   line,
                   "Curly brace closing",
                   ch);
        }



        /* Symbols */
        else if(issymbol(ch))
        {
            printf(BLUE "Line %2d : %-25s : %c\n" RESET,
                   line,
                   "Symbol",
                   ch);
        }

    }


    fclose(fin);


    if(curly_count > 0)
    {
        printf(RED "Error: '{' braces not balanced\n" RESET);
        return 0;
    }


    if(round_count > 0)
    {
        printf(RED "Error: '(' braces not balanced\n" RESET);
        return 0;
    }


    printf(GREEN "Successfully parsed\n" RESET);


    return 0;
}